import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { apiFetch, usuariosApi } from '../services/api'
import { useUsuario } from '../services/sesion'

const ROLES = {
  1: { textoRol: 'Cliente', claseBadge: 'bg-secondary' },
  2: { textoRol: 'Administrador', claseBadge: 'bg-dark' },
  3: { textoRol: 'Vendedor', claseBadge: 'bg-info text-dark' },
}

export default function ListarUsuarios() {
  const usuarioActual = useUsuario()
  const [usuarios, setUsuarios] = useState(null)
  const [error, setError] = useState(false)

  const cargar = () => {
    apiFetch('/api/usuarios')
      .then((respuesta) => {
        if (!respuesta.ok) throw new Error('Error del servidor')
        return respuesta.json()
      })
      .then(setUsuarios)
      .catch((err) => {
        console.log('Error al traer los usuarios:', err)
        setError(true)
      })
  }

  useEffect(() => {
    cargar()
  }, [])

  const handleEliminar = async (id, nombre) => {
    if (usuarioActual && usuarioActual.id_usuario === id) {
      alert('No puedes eliminar tu propia cuenta.')
      return
    }
    if (!window.confirm(`¿Estás seguro de desactivar al usuario "${nombre}"?`)) return
    try {
      await usuariosApi.eliminar(id)
      alert('Usuario desactivado correctamente.')
      cargar()
    } catch (err) {
      alert(err.message || 'Error al eliminar usuario.')
    }
  }

  return (
    <div className="background min-vh-100">
      <div className="container py-5">
        <div className="d-flex justify-content-between align-items-center mb-4">
          <h1 className="mb-0 herotitulo" style={{ color: 'white', fontSize: 'xx-large' }}>
            Lista de Usuarios Registrados
          </h1>
          <Link to="/crearUsuario" className="btn btn-light fw-bold">Nuevo usuario</Link>
        </div>
        <div className="card shadow border-0 rounded-4 p-4">
          <div className="table-responsive">
            <table className="table table-striped align-middle">
              <thead>
                <tr>
                  <th scope="col">RUN</th>
                  <th scope="col">Nombre</th>
                  <th scope="col">Apellidos</th>
                  <th scope="col">Correo</th>
                  <th scope="col">Rol</th>
                  <th scope="col">Acciones</th>
                </tr>
              </thead>
              <tbody id="cuerpoTablaUsuarios">
                {error && (
                  <tr>
                    <td colSpan={6} className="text-center text-danger">
                      No se pudieron cargar los usuarios.
                    </td>
                  </tr>
                )}
                {!error && usuarios && usuarios.length === 0 && (
                  <tr>
                    <td colSpan={6} className="text-center">No hay usuarios registrados.</td>
                  </tr>
                )}
                {!error &&
                  usuarios &&
                  usuarios.map((user) => {
                    const infoRol = ROLES[user.id_rol] || ROLES[1]
                    const esPropiaCuenta = usuarioActual && usuarioActual.id_usuario === user.id_usuario
                    return (
                      <tr key={user.id_usuario}>
                        <td>{user.run}</td>
                        <td>{user.nombre}</td>
                        <td>{user.apellidos}</td>
                        <td>{user.correo}</td>
                        <td><span className={`badge ${infoRol.claseBadge}`}>{infoRol.textoRol}</span></td>
                        <td>
                          <Link
                           to={`/historialCompras/${user.id_usuario}`}
                            className="btn btn-warning btn-sm fw-bold"
                          >
                            Editar
                          </Link>
                          <Link
                            to={`/historialCompras/${user.id_usuario}`}
                            className="btn btn-outline-dark btn-sm fw-bold ms-2"
                          >
                            Historial
                          </Link>
                          {!esPropiaCuenta && (
                            <button
                              type="button"
                              className="btn btn-outline-danger btn-sm fw-bold ms-2"
                              onClick={() => handleEliminar(user.id_usuario, `${user.nombre} ${user.apellidos}`)}
                            >
                              Eliminar
                            </button>
                          )}
                        </td>
                      </tr>
                    )
                  })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <br />
    </div>
  )
}
