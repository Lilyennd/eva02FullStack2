import { useEffect, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { apiFetch, subirImagen } from '../services/api'
import CamposProducto, { IMAGENES_PRODUCTO, useCatalogosProducto } from './CamposProducto'

const productoVacio = {
  codigo_producto: '', nombre: '', descripcion: '', precio: '', id_categoria: '',
  stock: '', stock_critico: '', origen: '', imagen_principal: '',
  kilates: '', corte: '', claridad: '', color: '', certificado: '', peso_gramos: '',
  en_oferta: false, precio_oferta: '',
}

export default function ModificarProducto() {
  const navigate = useNavigate()
  // Lee el id de /modificarProducto/3 (si entras sin id, queda undefined)
  const { id: idInicial } = useParams()
  const { categorias, imagenes } = useCatalogosProducto(IMAGENES_PRODUCTO)
  const [listaProductos, setListaProductos] = useState([])
  const [idSeleccionado, setIdSeleccionado] = useState('')
  const [datos, setDatos] = useState(productoVacio)
  // Imagen nueva elegida por el usuario (si no elige ninguna, queda null)
  const [archivo, setArchivo] = useState(null)

  // Al cargar, trae todos los productos y, si venía un id, deja ese seleccionado
  useEffect(() => {
    let vigente = true
    apiFetch('/api/productos')
      .then((respuesta) => respuesta.json())
      .then((lista) => {
        if (!vigente) return
        setListaProductos(lista)
        if (idInicial) seleccionar(idInicial, lista)
      })
      .catch(() => {
        if (vigente) alert('Error al cargar los productos desde la base de datos.')
      })
    return () => {
      vigente = false
    }
  }, [idInicial])

  const handleChange = (e) => {
    const { id, value } = e.target
    setDatos((prev) => ({ ...prev, [id]: value }))
  }

  // Rellena el formulario con los datos del producto elegido
  const seleccionar = (id, lista) => {
    setIdSeleccionado(id)
    setArchivo(null)

    const elegido = lista.find((p) => String(p.id_producto) === String(id))
    if (elegido) {
      setDatos({
        codigo_producto: elegido.codigo_producto,
        nombre: elegido.nombre,
        descripcion: elegido.descripcion || '',
        precio: elegido.precio,
        stock: elegido.stock,
        stock_critico: elegido.stock_critico || 0,
        id_categoria: elegido.id_categoria,
        imagen_principal: elegido.imagen_principal || '',
        origen: elegido.origen || '',
        kilates: elegido.kilates || '',
        corte: elegido.corte || '',
        claridad: elegido.claridad || '',
        color: elegido.color || '',
        certificado: elegido.certificado || '',
        peso_gramos: elegido.peso_gramos || '',
        en_oferta: !!elegido.en_oferta,
        precio_oferta: elegido.precio_oferta || '',
      })
    }
  }

  const handleSeleccion = (e) => seleccionar(e.target.value, listaProductos)

  const handleSubmit = async (evento) => {
    evento.preventDefault()

    if (idSeleccionado === '') {
      alert('Por favor, selecciona un producto primero.')
      return
    }

    if (datos.en_oferta && (datos.precio_oferta === '' || Number(datos.precio_oferta) >= Number(datos.precio))) {
      alert('El precio de oferta es obligatorio y debe ser menor al precio normal.')
      return
    }

    // 1) Si se eligió una imagen nueva, se sube primero; si no, se conserva la actual
    let imagen = datos.imagen_principal || null
    if (archivo) {
      try {
        imagen = await subirImagen('productos', archivo)
      } catch (err) {
        alert('No se pudo subir la imagen: ' + err.message)
        return
      }
    }

    // 2) Se actualiza el producto con esa imagen
    const paqueteDatos = {
      nombre: datos.nombre,
      descripcion: datos.descripcion || null,
      precio: Number(datos.precio),
      stock: Number(datos.stock),
      stock_critico: Number(datos.stock_critico),
      id_categoria: Number(datos.id_categoria),
      origen: datos.origen || null,
      kilates: datos.kilates || null,
      corte: datos.corte || null,
      claridad: datos.claridad || null,
      color: datos.color || null,
      certificado: datos.certificado || null,
      peso_gramos: Number(datos.peso_gramos) || null,
      imagen_principal: imagen,
      en_oferta: !!datos.en_oferta,
      precio_oferta: datos.en_oferta ? Number(datos.precio_oferta) : null,
    }

    try {
      const respuesta = await apiFetch('/api/productos/' + idSeleccionado, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(paqueteDatos),
      })

      if (respuesta.ok) {
        alert('El producto se actualizó correctamente')
        navigate('/inventario')
      } else {
        alert('Hubo un problema al guardar en la base de datos.')
      }
    } catch {
      alert('Error de conexión con el servidor.')
    }
  }

  return (
    <div className="background min-vh-100">
      <div className="container">
        <div className="row justify-content-center py-5">
          <div className="col-md-9 col-lg-7">
            <div className="card shadow border-0 rounded-4">
              <div className="card-body p-4 p-md-5">
                <h3 className="card-title text-center mb-4 fw-bold">Modificar Producto</h3>
                <div id="mensajeProducto"></div>
                <form id="formProducto" noValidate onSubmit={handleSubmit}>
                  <div className="mb-3">
                    <label htmlFor="select_producto" className="form-label">Seleccionar Producto a Modificar</label>
                    <select className="form-select bg-light fw-bold" id="select_producto" required
                      value={idSeleccionado} onChange={handleSeleccion}>
                      <option value="" disabled>Selecciona un producto...</option>
                      {listaProductos.map((p) => (
                        <option key={p.id_producto} value={p.id_producto}>
                          {p.codigo_producto + ' - ' + p.nombre}
                        </option>
                      ))}
                    </select>
                    <div className="form-text">Elige el producto que deseas actualizar.</div>
                  </div>

                  <CamposProducto
                    datos={datos}
                    onChange={handleChange}
                    categorias={categorias}
                    imagenes={imagenes}
                    stepPrecio="100000"
                  />

                  {/* Cambiar la imagen: si no eliges ninguna, se conserva la actual */}
                  <div className="mb-3">
                    <label htmlFor="archivoImagen" className="form-label">Subir imagen nueva (opcional)</label>
                    <input
                      type="file"
                      className="form-control"
                      id="archivoImagen"
                      accept="image/png,image/jpeg,image/webp"
                      onChange={(e) => setArchivo(e.target.files[0] || null)}
                    />
                    <div className="form-text">JPG, PNG o WEBP, máximo 5 MB. Si no eliges ninguna, se mantiene la actual.</div>
                  </div>

                  <div className="d-flex gap-2 mt-3">
                    <button type="submit" className="btn btn-dark flex-fill py-2">Modificar Producto</button>
                    <Link to="/inventario" className="btn btn-outline-secondary flex-fill py-2 text-center">Cancelar</Link>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
      <br />
    </div>
  )
}